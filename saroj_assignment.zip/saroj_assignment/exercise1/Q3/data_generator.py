try:
    no_of_data=int(input("Enter the Value of n:"))
    import random
    import string
    import ipaddr, ipaddress

    def sapId(stringLength=8):
        letters = string.ascii_lowercase
        random_name =''.join(random.choice(letters) for i in range(stringLength))
        sampid = random_name 
        return sampid

    print("*** SapId List ***")

    for _ in range(no_of_data):
        print(sapId(8))

    print("\n")

    def hostName(stringLength=8):
        letters = string.ascii_lowercase
        random_name =''.join(random.choice(letters) for i in range(stringLength))
        hostname = 'www.' + random_name + '.com'
        return hostname

    print("*** HostName List ***")

    for _ in range(no_of_data):
        print(hostName(8))

    print("\n")
    print("*** Loopback List ***")
    # for addr in ipaddress.IPv4Network('127.0.0.0/28'):
    #     print(addr)

    for i in range(no_of_data):
        print('127.0.0.' +str(i))

    print("\n")
    print("*** Mac Address List ***")

    def randomMAC():
        mac = [ 0x00, 0x16, 0x3e,
            random.randint(0x00, 0x7f),
            random.randint(0x00, 0xff),
            random.randint(0x00, 0xff) ]
        return ':'.join(map(lambda x: "%02x" % x, mac))

    for _ in range(no_of_data):
        print(randomMAC())
except ValueError:
    print("This is not a whole number.")


# if type(no_of_data) == int:

#     import random
#     import string
#     import ipaddr, ipaddress

#     def sapId(stringLength=8):
#         letters = string.ascii_lowercase
#         random_name =''.join(random.choice(letters) for i in range(stringLength))
#         sampid = random_name 
#         return sampid

#     print("*** SapId List ***")

#     for _ in range(no_of_data):
#         print(sapId(8))

#     print("\n")

#     def hostName(stringLength=8):
#         letters = string.ascii_lowercase
#         random_name =''.join(random.choice(letters) for i in range(stringLength))
#         hostname = 'www.' + random_name + '.com'
#         return hostname

#     print("*** HostName List ***")

#     for _ in range(no_of_data):
#         print(hostName(8))

#     print("\n")
#     print("*** Loopback List ***")
#     # for addr in ipaddress.IPv4Network('127.0.0.0/28'):
#     #     print(addr)

#     for i in range(no_of_data):
#         print('127.0.0.' +str(i))

#     print("\n")
#     print("*** Mac Address List ***")

#     def randomMAC():
#         mac = [ 0x00, 0x16, 0x3e,
#             random.randint(0x00, 0x7f),
#             random.randint(0x00, 0xff),
#             random.randint(0x00, 0xff) ]
#         return ':'.join(map(lambda x: "%02x" % x, mac))

#     for _ in range(no_of_data):
#         print(randomMAC())
# else:
#      print("You must enter a number")
