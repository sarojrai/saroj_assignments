from django.shortcuts import redirect
from django.shortcuts import render
from django.views import View
from django.views.generic import ListView
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
import json
from django.http import HttpResponse
from django.http import JsonResponse
from django.conf import settings
from django.http import Http404, StreamingHttpResponse, FileResponse
from .models import RouterInfo
from .forms import RouterForm
import os


# Create your views here.


def index(request):
    return render(request, 'app/index.html')


class RouterInfoList(ListView):
    template_name = 'app/list_view.html'

    def get(self, request, *args, **kwargs):
        """
        Return the list of all the active roles data.
        """
        # search_filter = self.request.GET.get('filter', '')
        # if not search_filter:
        #     queryset = RouterInfo.objects.filter(is_active=True).all()
        sapid = self.request.GET.get('sapid', '')
        hostname = self.request.GET.get('hostname', '')
        loopback = self.request.GET.get('loopback', '')
        mac_address = self.request.GET.get('mac_address', '')

        q =  {k +'__icontains':v for k, v in request.GET.items() if v}
        queryset = RouterInfo.objects.filter(**q).all()
        

        # if sapid:
        #     queryset = RouterInfo.objects.filter(is_active=True, sapid__icontains=sapid).all()
        # elif hostname:
        #     queryset = RouterInfo.objects.filter(is_active=True, hostname__icontains=hostname).all()
        # elif mac_address:
        #     queryset = RouterInfo.objects.filter(is_active=True, mac_address__icontains=mac_address).all()
        # elif loopback:
        #     queryset = RouterInfo.objects.filter(is_active=True, loopback__icontains=loopback).all()
       
        # else:
        #     queryset = RouterInfo.objects.filter(is_active=True).all()


        paginator = Paginator(queryset, 5)
        try:
            page = int(request.GET.get('page', '1'))
        except:
            page = 1

        try:
            role_list = paginator.page(page)
        except PageNotAnInteger:
            role_list = paginator.page(1)
        except EmptyPage:
            role_list = paginator.page(paginator.num_pages)

        # Get the index of the current page
        index = role_list.number - 1

        # This value is maximum index of pages, so the last page - 1
        max_index = len(paginator.page_range)

        # range of 7, calculate where to slice the list
        start_index = index - 3 if index >= 3 else 0
        end_index = index + 4 if index <= max_index - 4 else max_index

        # new page range
        page_range = paginator.page_range[start_index:end_index]

        # showing first and last links in pagination
        if index >= 4:
            start_index = 1
        if end_index - index >= 4 and end_index != max_index:
            end_index = max_index
        else:
            end_index = None

        return render(request, self.template_name,
                      {'record_list': role_list, 'page_range': page_range, 'start_index': start_index,
                       'end_index': end_index, 'max_index': max_index})


def create(request):
    context = {}
    form = RouterForm(request.POST)
    #print(request.POST)
    context['form'] = form
    router_info = RouterInfo.objects.all()
    context['router_info'] = router_info
    if request.POST:
        if form.is_valid():
            router_info = RouterInfo(sapid=request.POST['sapid'], hostname=request.POST['hostname'],
                                     loopback=request.POST['loopback'], mac_address=request.POST['mac_address'])
            router_info.save()
            return redirect('/')
        #print(form.errors)
        return render(request, "app/index.html", context)


def delete(request, pk):
    # router_info = RouterInfo.objects.get(pk=pk)
    # router_info.is_active = False
    # router_info.save()
    inactive_user = RouterInfo.objects.filter(id=pk).update(is_active=False)
    data = {}
    if inactive_user:
        data['message'] = 1
    else:
        data['message'] = 0

    return JsonResponse(data)


class RouterInfoUpdate(View):
    """
        This class will covers the update view of router info.
    """
    form_class = RouterForm
    template_name = 'app/edit.html'

    def get(self, request, pk):
        """
        Get router data by primary key.
        :param request:
        :param pk:
        :return: Return status as 200 if form is valid else it will return status as 400 if data is invalid.
        """
        router_data = RouterInfo.objects.get(pk=pk, is_active=True)
        if router_data:
            return render(request, self.template_name, {'router_info': router_data}, status=200)
        return render(request, self.template_name, status=400)

    def post(self, request, pk):
        """
        Update new router info instance.
        :param request:
        :param pk:
        :return: Return status as 200 if form is valid else it will return status as 400 if data is invalid.
        """
        form = self.form_class(request.POST)

        if form.is_valid():
            RouterInfo.objects.filter(id=pk).update(sapid=request.POST['sapid'], hostname=request.POST['hostname'],
                                     loopback=request.POST['loopback'], mac_address=request.POST['mac_address'])

            return redirect('/app')
        return render(request, self.template_name, {'form':form, 'router_info': form.data, 'ValidationError': form}, status=400)

def download(request,file_name):
    
    try:
        # file_path1='/router_info.txt'
        file_path= settings.MEDIA_ROOT + "/" +file_name + ".txt"
        print(file_path)
        response = FileResponse(open(file_path, 'rb'))
        response['content_type'] = "application/octet-stream"
        response['Content-Disposition'] = 'attachment; filename=' + os.path.basename(file_path)
        return response
    except Exception:
        raise Http404
    