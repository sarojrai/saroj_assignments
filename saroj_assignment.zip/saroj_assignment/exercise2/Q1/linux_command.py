import subprocess
import os
# import sys
p = subprocess.run(["scp", "Token_genrate.txt", "remote_upload"])
#p = subprocess.run(["ftp", "Token_genrate.txt", "remote_upload"])
#p = subprocess.run(["sftp", "Token_genrate.txt", "remote_upload"])
#subprocess.call(["ls", "-l"])
#output = subprocess.check_output(['ls', '-1'])


# SSH

# HOST="127.0.0.1"
# ssh = subprocess.Popen(["ssh",
#                         "%s" % HOST],
#                         stdin=subprocess.PIPE,
#                         stdout=subprocess.PIPE,
#                         stderr=subprocess.PIPE,
#                         universal_newlines=True,
#                         bufsize=0)
#  # send ssh commands to stdin
# ssh.stdin.write("ls .\n")
# ssh.stdin.write("uname -a\n")
# ssh.stdin.write("uptime\n")
# ssh.stdin.close()
#  # fetch output
# for line in ssh.stdout:
#     print(line),

