CREATE VIEW cisco AS
SELECT sapid, hostname,loopback,mac_address
FROM router;
