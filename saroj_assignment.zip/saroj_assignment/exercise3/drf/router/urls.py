from django.urls import include, path
from . import views

urlpatterns = [
  path('get', views.get),
  path('create', views.add),
  path('update/<str:loopback>', views.update),
  path('delete/<str:loopback>', views.delete),
  path('getsapid/<str:sapid>', views.getsapid),
  path('getiprange/<str:sapid>', views.getiprange)
]